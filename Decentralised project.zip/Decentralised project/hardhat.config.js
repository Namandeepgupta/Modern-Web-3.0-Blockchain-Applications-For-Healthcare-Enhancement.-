// Current Date and Time (UTC): 2025-01-03 20:11:46
// Current User's Login: AdityaVatsS

require("@nomicfoundation/hardhat-toolbox");
require('dotenv').config();

const SEPOLIA_URL = "https://sepolia.infura.io/v3/2b8d7c19745c47fa97f4eec4104bc9b9";
const PRIVATE_KEY = "3e6c0c2303170aeba1d06ac8cacc5b9bfc62cb48763f40d184a82a68c897f269";

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.19",
  networks: {
    sepolia: {
      url: SEPOLIA_URL,
      accounts: [PRIVATE_KEY]
    }
  },
  paths: {
    sources: "./contracts",
    tests: "./test",
    cache: "./cache",
    artifacts: "./artifacts"
  }
};